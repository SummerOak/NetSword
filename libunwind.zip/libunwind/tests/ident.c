long
f (long val)
{
  return val;
}
